create database WT;

use WT;

create table wind_turbine (
     date text,
     Wind_speed double null,
     Power double null,
     Nacelle_ambient_temperature double null,
     Generator_bearing_temperature double null,
Gear_oil_temperature double null,
     Ambient_temperature double null,
     Rotor_Speed double null,
     Nacelle_temperature double null,
     Bearing_temperature double null,
     Generator_speed double null,
     Yaw_angle double null,
     Wind_direction double null,
     Wheel_hub_temperature double null,
     Gear_box_inlet_temperature double null,
     Failure_status text null
 );
 
show variables like 'secure_file_priv';

show variables like '%local%';

LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/Wind_turbine.csv'
INTO TABLE wind_turbine
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(date, @Wind_speed, @Power, @Nacelle_ambient_temperature, Generator_bearing_temperature, Gear_oil_temperature,
Ambient_temperature, Rotor_Speed, @Nacelle_temperature, Bearing_temperature, @Generator_speed, @Yaw_angle,
Wind_direction, Wheel_hub_temperature, @Gear_box_inlet_temperature, Failure_status)
SET Wind_speed = nullif((@Wind_speed), ''),
Power = nullif((@Power), ''),
Nacelle_ambient_temperature = nullif((@Nacelle_ambient_temperature), ''),
Nacelle_temperature = nullif((@Nacelle_temperature), ''),
Generator_speed = nullif((@Generator_speed), ''),
Yaw_angle = nullif((@Yaw_angle), ''),
Gear_box_inlet_temperature = nullif((@Gear_box_inlet_temperature), '');

#Total rows count
select count(*) from wind_turbine;

#To check the null count in wind speed
select count(*) from wind_turbine where Wind_speed is null;

#Check the dates and wind speeds where wind speed is null
select date,Wind_speed from wind_turbine where Wind_speed is null;

select count(*) from wind_turbine;

/*------Before Preprocessing-----*/

/*First Moment Business Decision*/

/*Mean*/

------- Calculating the mean value for Wind_speed--------
SELECT AVG (Wind_speed) AS mean_value FROM wind_turbine;

------- Mean value for Power--------
SELECT AVG (Power) AS mean_value FROM wind_turbine;

------- Mean value for Nacelle_ambient_temperature--------
SELECT AVG (Nacelle_ambient_temperature) AS mean_value FROM wind_turbine;

------- Mean value for Generator_bearing_temperature--------
SELECT AVG (Generator_bearing_temperature) AS mean_value FROM wind_turbine;

------- Mean value for Gear_oil_temperature--------
SELECT AVG (Gear_oil_temperature) AS mean_value FROM wind_turbine;

------- Mean value for Ambient_temperature--------
SELECT AVG (Ambient_temperature) AS mean_value FROM wind_turbine;

------- Mean value for Rotor_Speed--------
SELECT AVG (Rotor_Speed) AS mean_value FROM wind_turbine;

------- Mean value for Nacelle_temperature--------
SELECT AVG (Nacelle_temperature) AS mean_value FROM wind_turbine;

------- Mean value for Bearing_temperature--------
SELECT AVG (Bearing_temperature) AS mean_value FROM wind_turbine;

------- Mean value for Generator_speed--------
SELECT AVG (Generator_speed) AS mean_value FROM wind_turbine;

------- Mean value for Wheel_hub_temperature--------
SELECT AVG (Wheel_hub_temperature) AS mean_value FROM wind_turbine;

------- Mean value for Gear_box_inlet_temperature--------
SELECT AVG (Gear_box_inlet_temperature) AS mean_value FROM wind_turbine;

------- Mean value for Yaw_angle--------
SELECT AVG (Yaw_angle) AS mean_value FROM wind_turbine;

------- Mean value for Wind_direction--------
SELECT AVG (Wind_55direction) AS mean_value FROM wind_turbine;

/*Median*/

# Median for Wind_speed
SELECT AVG(Wind_speed) AS median
FROM (
    SELECT Wind_speed,
            ROW_NUMBER() OVER (ORDER BY Wind_speed) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

# Median for Power
SELECT AVG(Power) AS median
FROM (
    SELECT Power,
            ROW_NUMBER() OVER (ORDER BY Power) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

# Median for Nacelle_ambient_temperature
SELECT AVG(Nacelle_ambient_temperature) AS median
FROM (
    SELECT Nacelle_ambient_temperature,
            ROW_NUMBER() OVER (ORDER BY Nacelle_ambient_temperature) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

# Median for Generator_bearing_temperature
SELECT AVG(Generator_bearing_temperature) AS median
FROM (
    SELECT Generator_bearing_temperature,
            ROW_NUMBER() OVER (ORDER BY Generator_bearing_temperature) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

# Median for Gear_oil_temperature
SELECT AVG(Gear_oil_temperature) AS median
FROM (
    SELECT Gear_oil_temperature,
            ROW_NUMBER() OVER (ORDER BY Gear_oil_temperature) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

# Median for Ambient_temperature
SELECT AVG(Ambient_temperature) AS median
FROM (
    SELECT Ambient_temperature,
            ROW_NUMBER() OVER (ORDER BY Ambient_temperature) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

# Median for Rotor_Speed
SELECT AVG(Rotor_Speed) AS median
FROM (
    SELECT Rotor_Speed,
            ROW_NUMBER() OVER (ORDER BY Rotor_Speed) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

# Median for Nacelle_temperature
SELECT AVG(Nacelle_temperature) AS median
FROM (
    SELECT Nacelle_temperature,
            ROW_NUMBER() OVER (ORDER BY Nacelle_temperature) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

# Median for Bearing_temperature
SELECT AVG(Bearing_temperature) AS median
FROM (
    SELECT Bearing_temperature,
            ROW_NUMBER() OVER (ORDER BY Bearing_temperature) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

# Median for Generator_speed
SELECT AVG(Generator_speed) AS median
FROM (
    SELECT Generator_speed,
            ROW_NUMBER() OVER (ORDER BY Generator_speed) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

# Median for Yaw_angle
SELECT AVG(Yaw_angle) AS median
FROM (
    SELECT Yaw_angle,
            ROW_NUMBER() OVER (ORDER BY Yaw_angle) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

# Median for Wind_direction
SELECT AVG(Wind_direction) AS median
FROM (
    SELECT Wind_direction,
            ROW_NUMBER() OVER (ORDER BY Wind_direction) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

# Median for Wheel_hub_temperature
SELECT AVG(Wheel_hub_temperature) AS median
FROM (
    SELECT Wheel_hub_temperature,
            ROW_NUMBER() OVER (ORDER BY Wheel_hub_temperature) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

# Median for Gear_box_inlet_temperature
SELECT AVG(Gear_box_inlet_temperature) AS median
FROM (
    SELECT Gear_box_inlet_temperature,
            ROW_NUMBER() OVER (ORDER BY Gear_box_inlet_temperature) AS row_num,
            COUNT(*) OVER () AS total_count
    FROM wind_turbine
) AS median_subquery
WHERE row_num BETWEEN (total_count + 1) / 2 AND total_count / 2 + 1;

/*Mode*/

# Mode for Wind_speed
SELECT Wind_speed AS mode
FROM (
SELECT Wind_speed, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Wind_speed
ORDER BY frequency DESC
LIMIT 1
) AS mode;

# Mode for Power
SELECT Power AS mode
FROM (
SELECT Power, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Power
ORDER BY frequency DESC
LIMIT 1
) AS mode;

# Mode for Nacelle_ambient_temperature
SELECT Nacelle_ambient_temperature AS mode
FROM (
SELECT Nacelle_ambient_temperature, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Nacelle_ambient_temperature
ORDER BY frequency DESC
LIMIT 1
) AS mode;

# Mode for Generator_bearing_temperature
SELECT Generator_bearing_temperature AS mode
FROM (
SELECT Generator_bearing_temperature, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Generator_bearing_temperature
ORDER BY frequency DESC
LIMIT 1
) AS mode;

# Mode for Gear_oil_temperature
SELECT Gear_oil_temperature AS mode
FROM (
SELECT Gear_oil_temperature, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Gear_oil_temperature
ORDER BY frequency DESC
LIMIT 1
) AS mode;

# Mode for Ambient_temperature
SELECT Ambient_temperature AS mode
FROM (
SELECT Ambient_temperature, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Ambient_temperature
ORDER BY frequency DESC
LIMIT 1
) AS mode;

# Mode for Rotor_Speed
SELECT Rotor_Speed AS mode
FROM (
SELECT Rotor_Speed, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Rotor_Speed
ORDER BY frequency DESC
LIMIT 1
) AS mode;

# Mode for Nacelle_temperature
SELECT Nacelle_temperature AS mode
FROM (
SELECT Nacelle_temperature, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Nacelle_temperature
ORDER BY frequency DESC
LIMIT 1
) AS mode;

# Mode for Bearing_temperature
SELECT Bearing_temperature AS mode
FROM (
SELECT Bearing_temperature, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Bearing_temperature
ORDER BY frequency DESC
LIMIT 1
) AS mode;

# Mode for Generator_speed
SELECT Generator_speed AS mode
FROM (
SELECT Generator_speed, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Generator_speed
ORDER BY frequency DESC
LIMIT 1
) AS mode;

# Mode for Yaw_angle
SELECT Yaw_angle AS mode
FROM (
SELECT Yaw_angle, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Yaw_angle
ORDER BY frequency DESC
LIMIT 1
) AS mode;

# Mode for Wind_direction
SELECT Wind_direction AS mode
FROM (
SELECT Wind_direction, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Wind_direction
ORDER BY frequency DESC
LIMIT 1
) AS mode;

# Mode for Wheel_hub_temperature
SELECT Wheel_hub_temperature AS mode
FROM (
SELECT Wheel_hub_temperature, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Wheel_hub_temperature
ORDER BY frequency DESC
LIMIT 1
) AS mode;

# Mode for Gear_box_inlet_temperature
SELECT Gear_box_inlet_temperature AS mode
FROM (
SELECT Gear_box_inlet_temperature, COUNT(*) AS frequency
FROM wind_turbine
GROUP BY Gear_box_inlet_temperature
ORDER BY frequency DESC
LIMIT 1
) AS mode;


/*Second Moment Business Decision*/

/*Variance*/

------- Calculating the Variance value for Wind_speed--------
SELECT VARIANCE(Wind_speed) FROM wind_turbine;

------- VARIANCE for Power--------
SELECT VARIANCE(Power) FROM wind_turbine;

------- VARIANCE for Nacelle_ambient_temperature--------

SELECT VARIANCE(Nacelle_ambient_temperature) FROM wind_turbine;

------- VARIANCE for Generator_bearing_temperature--------
SELECT VARIANCE(Generator_bearing_temperature) FROM wind_turbine;

------- VARIANCE for Gear_oil_temperature--------
SELECT VARIANCE(Gear_oil_temperature) FROM wind_turbine;

------- VARIANCE for Ambient_temperature--------
SELECT VARIANCE(Ambient_temperature) FROM wind_turbine;

------- VARIANCE for Rotor_Speed--------
SELECT VARIANCE(Rotor_Speed) FROM wind_turbine;

------- VARIANCE for Nacelle_temperature--------
SELECT VARIANCE(Nacelle_temperature) FROM wind_turbine;

------- VARIANCE for Bearing_temperature--------
SELECT VARIANCE(Bearing_temperature) FROM wind_turbine;

------- VARIANCE for Generator_speed--------
SELECT VARIANCE(Generator_speed) FROM wind_turbine;

------- VARIANCE for Wheel_hub_temperature--------
SELECT VARIANCE(Wheel_hub_temperature) FROM wind_turbine;

------- VARIANCE for Gear_box_inlet_temperature--------
SELECT VARIANCE(Gear_box_inlet_temperature) FROM wind_turbine;

------- VARIANCE for Yaw_angle--------
SELECT VARIANCE(Yaw_angle) FROM wind_turbine;

------- VARIANCE for Wind_direction--------
SELECT VARIANCE(Wind_direction) FROM wind_turbine;

/*Standard Deviation*/

------- Calculating the Standard Deviation value for Wind_speed--------
SELECT STDDEV(Wind_speed) AS standard_deviation FROM wind_turbine;

------- Standard Deviation for Power--------
SELECT STDDEV(Power) AS standard_deviation FROM wind_turbine;

------- Standard Deviation for Nacelle_ambient_temperature--------
SELECT STDDEV(Nacelle_ambient_temperature) AS standard_deviation FROM wind_turbine;

------- Standard Deviation for Generator_bearing_temperature--------
SELECT STDDEV(Generator_bearing_temperature) AS standard_deviation FROM wind_turbine;

------- Standard Deviation for Gear_oil_temperature--------
SELECT STDDEV(Gear_oil_temperature) AS standard_deviation FROM wind_turbine;

------- Standard Deviation for Ambient_temperature--------
SELECT STDDEV(Ambient_temperature) AS standard_deviation FROM wind_turbine;

------- Standard Deviation for Rotor_Speed--------
SELECT STDDEV(Rotor_Speed) AS standard_deviation FROM wind_turbine;

------- Standard Deviation for Nacelle_temperature--------
SELECT STDDEV(Nacelle_temperature) AS standard_deviation FROM wind_turbine;

------- Standard Deviation for Bearing_temperature--------
SELECT STDDEV(Bearing_temperature) AS standard_deviation FROM wind_turbine;

------- Standard Deviation for Generator_speed--------
SELECT STDDEV(Generator_speed) AS standard_deviation FROM wind_turbine;

------- Standard Deviation for Wheel_hub_temperature--------
SELECT STDDEV(Wheel_hub_temperature) AS standard_deviation FROM wind_turbine;

------- Standard Deviation for Gear_box_inlet_temperature--------
SELECT STDDEV(Gear_box_inlet_temperature) AS standard_deviation FROM wind_turbine;

------- Standard Deviation for Yaw_angle--------
SELECT STDDEV(Yaw_angle) AS standard_deviation FROM wind_turbine;

------- Standard Deviation for Wind_direction--------
SELECT STDDEV(Wind_direction) AS standard_deviation FROM wind_turbine;

/*Range with Min & Max*/

-- Range for Wind_speed
SELECT Min(Wind_speed), Max(Wind_speed), Max(Wind_speed) - Min(Wind_speed) AS range_Wind_speed FROM wind_turbine;

-- Range for Power
SELECT Min(Power), Max(Power), Max(Power) - Min(Power) AS range_Power FROM wind_turbine;

-- Range for Nacelle_ambient_temperature
SELECT Min(Nacelle_ambient_temperature), Max(Nacelle_ambient_temperature), Max(Nacelle_ambient_temperature) - Min(Nacelle_ambient_temperature) AS range_Nacelle_ambient_temperature FROM wind_turbine;

-- Range for Generator_bearing_temperature
SELECT Min(Generator_bearing_temperature), Max(Generator_bearing_temperature), Max(Generator_bearing_temperature) - Min(Generator_bearing_temperature) AS range_Generator_bearing_temperature FROM wind_turbine;

-- Range for Gear_oil_temperature
SELECT Min(Gear_oil_temperature), Max(Gear_oil_temperature), Max(Gear_oil_temperature) - Min(Gear_oil_temperature) AS range_Gear_oil_temperature FROM wind_turbine;

-- Range for Ambient_temperature
SELECT Min(Ambient_temperature), Max(Ambient_temperature), Max(Ambient_temperature) - Min(Ambient_temperature) AS range_Ambient_temperature FROM wind_turbine;

-- Range for Rotor_Speed
SELECT Min(Rotor_Speed), Max(Rotor_Speed), Max(Rotor_Speed) - Min(Rotor_Speed) AS range_Rotor_Speed FROM wind_turbine;

-- Range for Nacelle_temperature
SELECT Min(Nacelle_temperature), Max(Nacelle_temperature), Max(Nacelle_temperature) - Min(Nacelle_temperature) AS range_Nacelle_temperature FROM wind_turbine;

-- Range for Bearing_temperature
SELECT Min(Bearing_temperature), Max(Bearing_temperature), Max(Bearing_temperature) - Min(Bearing_temperature) AS range_Bearing_temperature FROM wind_turbine;

-- Range for Generator_speed
SELECT Min(Generator_speed), Max(Generator_speed), Max(Generator_speed) - Min(Generator_speed) AS range_Generator_speed FROM wind_turbine;

-- Range for Yaw_angle
SELECT Min(Yaw_angle), Max(Yaw_angle), Max(Yaw_angle) - Min(Yaw_angle) AS range_Yaw_angle FROM wind_turbine;

-- Range for Wind_direction
SELECT Min(Wind_direction), Max(Wind_direction), Max(Wind_direction) - Min(Wind_direction) AS range_Wind_direction FROM wind_turbine;

-- Range for Wheel_hub_temperature
SELECT Min(Wheel_hub_temperature), Max(Wheel_hub_temperature), Max(Wheel_hub_temperature) - Min(Wheel_hub_temperature) AS range_Wheel_hub_temperature FROM wind_turbine;

-- Range for Gear_box_inlet_temperature
SELECT Min(Gear_box_inlet_temperature), Max(Gear_box_inlet_temperature), Max(Gear_box_inlet_temperature) - Min(Gear_box_inlet_temperature) AS range_Gear_box_inlet_temperature FROM wind_turbine;

/*Third Moment Business Decision*/

/*Skewness*/

------- Skewness value for Wind_speed--------
SELECT 3 * AVG(POW((Wind_speed - (SELECT AVG(Wind_speed) FROM wind_turbine)) / (SELECT STDDEV(Wind_speed) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;

------- Skewness for Power--------
SELECT 3 * AVG(POW((Power - (SELECT AVG(Power) FROM wind_turbine)) / (SELECT STDDEV(Power) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;
 
  ------- Skewness for Nacelle_ambient_temperature--------
SELECT 3 * AVG(POW((Nacelle_ambient_temperature - (SELECT AVG(Nacelle_ambient_temperature) FROM wind_turbine)) / (SELECT STDDEV(Nacelle_ambient_temperature) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;
 
  ------- Skewness for Generator_bearing_temperature--------
SELECT 3 * AVG(POW((Generator_bearing_temperature - (SELECT AVG(Generator_bearing_temperature) FROM wind_turbine)) / (SELECT STDDEV(Generator_bearing_temperature) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;
 
  ------- Skewness for Gear_oil_temperature--------
SELECT 3 * AVG(POW((Gear_oil_temperature - (SELECT AVG(Gear_oil_temperature) FROM wind_turbine)) / (SELECT STDDEV(Gear_oil_temperature) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;
 
  ------- Skewness for Ambient_temperature--------
SELECT 3 * AVG(POW((Ambient_temperature - (SELECT AVG(Ambient_temperature) FROM wind_turbine)) / (SELECT STDDEV(Ambient_temperature) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;
 
  ------- Skewness for Rotor_Speed--------
SELECT 3 * AVG(POW((Rotor_Speed - (SELECT AVG(Rotor_Speed) FROM wind_turbine)) / (SELECT STDDEV(Rotor_Speed) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;
 
  ------- Skewness for Nacelle_temperature--------
SELECT 3 * AVG(POW((Nacelle_temperature - (SELECT AVG(Nacelle_temperature) FROM wind_turbine)) / (SELECT STDDEV(Nacelle_temperature) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;
 
  ------- Skewness for Bearing_temperature--------
SELECT 3 * AVG(POW((Bearing_temperature - (SELECT AVG(Bearing_temperature) FROM wind_turbine)) / (SELECT STDDEV(Bearing_temperature) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;
 
  ------- Skewness for Generator_speed--------
SELECT 3 * AVG(POW((Generator_speed - (SELECT AVG(Generator_speed) FROM wind_turbine)) / (SELECT STDDEV(Generator_speed) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;
 
  ------- Skewness for Wheel_hub_temperature--------
SELECT 3 * AVG(POW((Wheel_hub_temperature - (SELECT AVG(Wheel_hub_temperature) FROM wind_turbine)) / (SELECT STDDEV(Wheel_hub_temperature) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;
 
  ------- Skewness for Gear_box_inlet_temperature--------
SELECT 3 * AVG(POW((Gear_box_inlet_temperature - (SELECT AVG(Gear_box_inlet_temperature) FROM wind_turbine)) / (SELECT STDDEV(Gear_box_inlet_temperature) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;
 
  ------- Skewness for Yaw_angle--------
SELECT 3 * AVG(POW((Yaw_angle - (SELECT AVG(Yaw_angle) FROM wind_turbine)) / (SELECT STDDEV(Yaw_angle) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;
 
  ------- Skewness for Wind_direction--------
SELECT 3 * AVG(POW((Wind_direction - (SELECT AVG(Wind_direction) FROM wind_turbine)) / (SELECT STDDEV(Wind_direction) FROM wind_turbine), 3))
  AS skewness FROM wind_turbine;
  
  
/*Fourth Moment Business Decision*/

/*Kurtosis*/

------- kurtosis value for Wind_speed--------
SELECT AVG(POW((Wind_speed - (SELECT AVG(Wind_speed) FROM wind_turbine)) / (SELECT STDDEV(Wind_speed) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;

 ------- kurtosis for Power--------
SELECT AVG(POW((Power - (SELECT AVG(Power) FROM wind_turbine)) / (SELECT STDDEV(Power) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;

 ------- kurtosis for Nacelle_ambient_temperature--------
SELECT AVG(POW((Nacelle_ambient_temperature - (SELECT AVG(Nacelle_ambient_temperature) FROM wind_turbine)) / (SELECT STDDEV(Nacelle_ambient_temperature) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;

 ------- kurtosis for Generator_bearing_temperature--------
SELECT AVG(POW((Generator_bearing_temperature - (SELECT AVG(Generator_bearing_temperature) FROM wind_turbine)) / (SELECT STDDEV(Generator_bearing_temperature) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;

 ------- kurtosis for Gear_oil_temperature--------
SELECT AVG(POW((Gear_oil_temperature - (SELECT AVG(Gear_oil_temperature) FROM wind_turbine)) / (SELECT STDDEV(Gear_oil_temperature) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;

 ------- kurtosis for Ambient_temperature--------
SELECT AVG(POW((Ambient_temperature - (SELECT AVG(Ambient_temperature) FROM wind_turbine)) / (SELECT STDDEV(Ambient_temperature) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;

 ------- kurtosis for Rotor_Speed--------
SELECT AVG(POW((Rotor_Speed - (SELECT AVG(Rotor_Speed) FROM wind_turbine)) / (SELECT STDDEV(Rotor_Speed) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;

 ------- kurtosis for Nacelle_temperature--------
SELECT AVG(POW((Nacelle_temperature - (SELECT AVG(Nacelle_temperature) FROM wind_turbine)) / (SELECT STDDEV(Nacelle_temperature) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;

 ------- kurtosis for Bearing_temperature--------
SELECT AVG(POW((Bearing_temperature - (SELECT AVG(Bearing_temperature) FROM wind_turbine)) / (SELECT STDDEV(Bearing_temperature) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;

 ------- kurtosis for Generator_speed--------
SELECT AVG(POW((Generator_speed - (SELECT AVG(Generator_speed) FROM wind_turbine)) / (SELECT STDDEV(Generator_speed) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;

 ------- kurtosis for Wheel_hub_temperature--------
SELECT AVG(POW((Wheel_hub_temperature - (SELECT AVG(Wheel_hub_temperature) FROM wind_turbine)) / (SELECT STDDEV(Wheel_hub_temperature) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;

 ------- kurtosis for Gear_box_inlet_temperature--------
SELECT AVG(POW((Gear_box_inlet_temperature - (SELECT AVG(Gear_box_inlet_temperature) FROM wind_turbine)) / (SELECT STDDEV(Gear_box_inlet_temperature) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;

 ------- kurtosis for Yaw_angle--------
SELECT AVG(POW((Yaw_angle - (SELECT AVG(Yaw_angle) FROM wind_turbine)) / (SELECT STDDEV(Yaw_angle) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;

 ------- kurtosis for Wind_direction--------
SELECT AVG(POW((Wind_direction - (SELECT AVG(Wind_direction) FROM wind_turbine)) / (SELECT STDDEV(Wind_direction) FROM wind_turbine), 4))
AS kurtosis FROM wind_turbine;